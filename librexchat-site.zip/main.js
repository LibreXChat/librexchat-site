import { loadTranslations } from './translations.js';
import { setupFooter } from './components/footer.js';
import { setupNavbar } from './components/navbar.js';
import { setupMainPage } from './components/main.js';
import { setupRulesPage } from './components/rules.js';

const t = loadTranslations('ru');
setupNavbar(t);
setupMainPage(t);
setupRulesPage(t);
setupFooter(t);